package com.example.intentsproj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        final int number1 = intent.getIntExtra(MainActivity.EXTRA_NUMBER1, 0);
        final int number2 = intent.getIntExtra(MainActivity.EXTRA_NUMBER2, 0);

        TextView textView1 = (TextView) findViewById(R.id.textView1);
        TextView textView2 = (TextView) findViewById(R.id.textView2);

        textView1.setText(""+number1);
        textView2.setText(""+number2);

        final TextView textView3 = (TextView) findViewById(R.id.textView4);

        Button btn2 = (Button) findViewById(R.id.button2);
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
               textView3.setText(""+number1+" + "+number2+" = "+(number1+number2));
            }

        });

        Button btn3 = (Button) findViewById(R.id.button3);
        btn3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                textView3.setText(""+number1+" - "+number2+" = "+(number1-number2));
            }

        });

        Button btn4 = (Button) findViewById(R.id.button4);
        btn4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                textView3.setText(""+number1+" * "+number2+" = "+(number1*number2));
            }

        });

        Button btn5 = (Button) findViewById(R.id.button5);
        btn5.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                float i =  (float) number1/number2;
                textView3.setText(""+number1+" / "+number2+" = "+i);
            }

        });
    }
}
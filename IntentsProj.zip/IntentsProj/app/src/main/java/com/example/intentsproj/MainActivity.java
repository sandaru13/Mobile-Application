package com.example.intentsproj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button button;
    public static final String EXTRA_NUMBER1 = "com.example.MainActivity.EXTRA_NUMBER1";
    public static final String EXTRA_NUMBER2 = "com.example.MainActivity.EXTRA_NUMBER2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    button =(Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View v){
            Toast.makeText(MainActivity.this,"Message Sending...",Toast.LENGTH_SHORT).show();
            openSecondActivity();
        }

    });

}
    public void openSecondActivity(){

        EditText editText1 = (EditText) findViewById(R.id.editText1);
        int number1 = Integer.parseInt(editText1.getText().toString());

        EditText editText2 = (EditText) findViewById(R.id.editText2);
        int number2 = Integer.parseInt(editText2.getText().toString());

        Intent intent = new Intent(this, SecondActivity.class);
        intent.putExtra(EXTRA_NUMBER1, number1);
        intent.putExtra(EXTRA_NUMBER2, number2);
        startActivity(intent);
    }

}

